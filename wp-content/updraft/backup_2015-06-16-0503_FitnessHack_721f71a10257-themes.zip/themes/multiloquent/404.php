<?php
/**
 * The template for displaying 404 pages (Not Found)
 * @package multiloquent
 */

/**
 * 404 error page template part
 *
 * @package multiloquent
 */

get_header();
require(locate_template('error-snippet.php'));
get_footer();
