=== Video Gallery ===
Contributors: Huge-IT
Donate link: http://huge-it.com/video-gallery/
Tags: video gallery, gallery, video, youtube, vimeo, wp gallery, media gallery, thumbnail video player, video plugin, vimeo gallery, youtube gallery, embed videos, youtube player, vimeo player, Video Player plugin, videos, wordpress, wordpress gallery, wordpress youtube, wordpress video, video portfolio, video slider, video slideshow, free video gallery, gallery video, mobile responsive, video player, player, video lightbox, widget video, free video, free gallery, slideshow, videos, video galleri, responsive gallery, best video,
Requires at least: 3.0.1
Tested up to: 4.2.2
Stable tag: 1.2.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Video Gallery plugin was created and specifically designed to show your video files in unusual splendid ways.

== Description ==

### Wordpress Video Gallery

[Wordpress Video Gallery](http://huge-it.com/video-gallery/)  
[Demo Video Gallery Admin](http://huge-it.com/wordpress-plugins-video-gallery-demo-admin/)  
[Demo Video Gallery](http://huge-it.com/wordpress-video-gallery-demo-1-content-popup/)  
[User Manual Video Gallery](http://huge-it.com/wordpress-plugins-video-gallery-user-manual/)  

https://www.youtube.com/watch?v=Re16ci9iGVU

Video Gallery plugin was created and specifically designed to show your videos from Vimeo and Youtube in unusual splendid ways. It has 5 good-looking views. Each are made in different taste so that you can choose any of them, according to the style of your website.

* Upload the video in your Video Gallery.
* Wright a title.
* Add description.
* Give some link.

Video gallery gives you the choice between 5 unrepeatable views. Tt has a view to show your videos with it’s information next to it in a beautiful popup, or the same view can be slide, in the second view, then you can choose to demonstrate  the videos in lightbox, or only slide the videos, in the next view, set up the way to slide and have fun, the last view is to show your videos in a little box which can be opened in lightbox and be slide at a time. So the choice are huge. You can provide all the information as from uploader panel, as after inserting in the Video Gallery panel.

Each of the view has changeable options in ‘General Options’ section of Video Gallery. Every detail is allowed to be change so that our users be satisfy of the results they get by using Video Gallery plugin. And everything are so easy to use that even your child can manage it. Make the Video shows. And demonstrate the content of your website in more kindly and pleasant way. 

The  Video Gallery allows you to add video from 2 kind of sources, it is Vimeo and Youtube. From time to time we will make all kind of updates, and add many other even better view to our Video Gallery, so that to be competitive among the other Video plugins in WordPress. So we have an aim to be the best Video Gallery and we will achieve our goal. Now it time for you to install and just try how nice it works!

### Video Gallery / Content popup - Video Gallery
This view has been made for showing your videos in popup with the information, that is given to the videos and the title, In the popup you can also find a Link button which takes to another page. The front image of your video will be settled be in compact box with zoom icon on it. Clicking on them and open the video in popup.

### Content video slider - Video Gallery
This view will introduce your video with it’s description and title next to it, in a wonderful slider. Choose the way to change the slides,m and enjoy sliding each video with the content.

### LIghtbox Video Gallery - Video Gallery
This view shows only the videos, without any text in a boxes, which will open in lightbox while clicking on them, it is also possible to adjust the style of the lightbox, in Lightbox Options section.

### Video Slider - Video Gallery
Show your videos in unique way by using Slider view. Here you can put the title and description straight on the video, choose the manner of sliding your videos, change styles and enjoy sliding your videos.

### Thumbnails - Video Gallery
Breathe new life to your site, show videos using thumbnails view. Pick a background image for the video. Open them in Lightbox and enjoy the show.


== Installation ==

### First download the ZIP file ,

1. Log in to your website administrator panel.   
2. Go to Plugins page, and add new plugin.    
3. Upload [WordPress Video Gallery](https://wordpress.org/plugins/gallery-video/). 
4. Click `Install Now` button.     
5. Then click `Activate Plugin` button. 

Now you can set your Video Gallery options, images and use our Video Gallery.

== Screenshots ==

1.  WordPress Video Gallery view 1 - Video Gallery / Content Popup
11.  WordPress Video Gallery view 1 - Video Gallery / Content Popup
2.  WordPress Video Gallery view 2 - Content Video Slider
3.  WordPress Video Gallery view 3 - Lightbox Video Gallery
4.  WordPress Video Gallery view 4 - Video Slider
5.  WordPress Video Gallery view 5 - Video Gallery - Thumbnails
51.  WordPress Video Gallery view 5 - Video Gallery - Thumbnails
52.  WordPress Video Gallery view 5 - Video Gallery - Thumbnails
6.  WordPress Video Gallery Admin Page
62.  WordPress Video Gallery Admin Page

== Frequently Asked Questions ==

### Video Gallery

**How to get a copy of most recent version ? **
Pro users can get update versions contacting us by info@huge-it.com.
Free version  users will find update notification in their wordpress admin panel.

**I have paid for pro version and didn’t get the link or file to update**
If you made purchase and didn’t get the file, or file was corrupt, contact us by info@huge-it.com and send “order number”, we will check and send you the file as soon as possible

**Have purchased pro version still get the announcement to buy the commercial version to change settings. What to do ?**
This can happen because of your browser’s cache files. Press ctrl+f5 (Chrome, FF) in order to clean them, if you use safari, etc., clean from browser settings

**Will I lose all my changes that I made in free version, if I update to pro version?**
All kind of changes made in free version will remain, even if you delete the plugin

**How to change “New Video Gallery” name?**
In order to change Video Gallery name just double click on it’s name (on top tabs)

**I have already purchased Multi Site version, how do I upgrade it to Developer version, without buying it again?**
If you have any pro version of our products and want to upgrade it, you do not need to buy the new one again, you only need to pay the difference price.
For example, if you have personal version and need to upgrade to Multi Site, just buy one more personal, and contact us by info@huge-it.com, send the receipt and we will send Multi Site version, from Multi Site to Developer, just buy one personal, and ask us for Developer version.

**I’ve bought the commercial license,  installed the file but the Plugin seems to be still in free version, what to do?**
After installation of pro version, in General Options all your changes will be saved!
If you still see "free version" notification after installation of pro version
* 1) try to clean your cache files if this will not help
* 2) delete, and install the plugin again

**I have multy sites, and the plugin works only on one, but not other sites, why?**
If you use multy site (have number of sites) when you install a plugin in main page, it will not work on other pages. 
In order it could work there too, you should. 
1) deactivate the plugin from main page
2) go to the other pages and activate it there one by one 
3) after all will be activated, go back to your main page and activate it

### If you think, that you found a bug in our [WordPress Video Gallery](http://huge-it.com/wordpress-video-gallery/) plugin or have any question contact us at [info@huge-it.com](mailto:info@huge-it.com).
    
== Changelog ==

= 1.2.5 =
*  Security bug fixed.

= 1.2.4 =
*  Bugs has been fixed on Video Gallery.

= 1.2.3 =
*  Bugs have been fixed on Video Gallery.

= 1.2.2 =
*  Bugs have been fixed on Video Gallery.

= 1.2.1 =
*  Added new view Justified.

= 1.2.0 =
*  Bugs have been fixed on Video Gallery.

= 1.1.9 =
*  Bugs have been fixed on Video Gallery.

= 1.1.8 =
*  Bugs have been fixed on Video Gallery.

= 1.1.7 =
*  Bugs have been fixed on Video Gallery.

= 1.1.6 =
*  Bugs have been fixed on Video Gallery.

= 1.1.5 =
*  Bugs have been fixed on Video Gallery.

= 1.1.4 =
*  Alt tag added in images.

= 1.1.3 =
*  Bugs have been fixed on Video Gallery.

= 1.1.2 =
*  Bugs have been fixed on Video Gallery.

= 1.1.1 =
*  Bugs have been fixed on Video Gallery.

= 1.1.0 =
*  Bugs have been fixed on Video Gallery.

= 1.0.9 =
*  Two or more video galleries already available on one page.

= 1.0.8 =
*  Bugs have been fixed on Video Gallery.

= 1.0.7 =
*  Bugs have been fixed on Video Gallery's lightbox.

= 1.0.6 =
*  Youtube links bags has been fixed in Video Gallery .

= 1.0.5 =
*  Video Gallery bag fixed.

= 1.0.4 =
*  Notices errors has been fixed in Video Gallery.

= 1.0.3 =
*  SQL injection bag fixed in Video Gallery.

= 1.0.2 =
*  Video Gallery bag fixed.

= 1.0.1 =
*  Video Gallery bag fixed.

= 1.0.0 =
*  Video Gallery added.

==Wordpress Adding a Video Gallery==

### Step 1 Creating a Video Gallery

Huge-IT Video Gallery > Add New Video Gallery

* Add video link. Video links can be add from Youtube and Vimeo.
* Title. Wright a title to the video
* Description. Wright some information about video content
* URL.You can add a link to another page that is related to the video

### Inserting Created Video Gallery.

After you created Video Gallery on the right side find 3 blocks.

* 1.Views. In this block you can choose one from 5 unrepeatable views.
* 2.Usage. Here is located the shortcode Of your Video Gallery. By Copy&Paset up this shortcode can be inserted wherever you need in your post. Or it is possible to add the shortcode automaticly. On post window just pressing on add video gallery button the shortcode will be inserted into post.
* 3.Template include. Insert this code into your template,to make the inserting the video gallery easy for using in custom location within theme.

### Step 2. General Options of Video Gallery

In this section you can modify your Video Gallery in more details. That will change the features of each view you choose.

### 2.1 Video Gallery/Content popup

Video element Styles

Video Video-element Width. Specify preferable width of your videos

Video element Height. Specify desired high of posted videos.

Video element Border Width. Specify preferable width for surrounded border of the Video-element

Video element Border colour. Select preferable colour for surrounded border

Video element's Video-image Overlay colour. Select a colour for the overlay on the video as you hold the mouse arrow on it

Video element's Video-image Overlay Transparency. Determine preferable transparency degree for the video overlay

Zoom image Style. Determine black or white colour for zoom icon

**Popup Styles - Video Gallery**

* Popup Background color. Edit to set preferable background colour of popup in your 
* Popup Overlay color.Choose preferable colour for popup overlay in your
* Popup Overlay Transparency. Specify preferable degree of background transparency in your 
* Popup Close Button Style. Edit what  colour for  “X” icon would you like 					
* Show Separator Lines. Select to show separation lines between title and text in popup.

**Popup Description - Video Gallery**

* Show Description. Select to show the description of the video. 
* Description Font Size. Determine preferable size of description font.
* Description Font color. Set preferable colour of description text.

**Video-element Title - Video Gallery**

* Video-element Title Font Size. Edit preferable size of title font in 
* Video-element Title Font color. Edit preferable colour of title 
* Video-element Title Background color. Determine preferable colour of title’s background

**Video-element Link button - Video Gallery**

* Show Link button on Video-element. Select to show “View More” button on the video
* Link button Text. You can change the “View More” button text
* Link button Font Size. Choose preferable size of Link-button 
* Link button Font color. Determine preferable colour of link font 
* Link button Background color. Determine preferable colour for link background 

**Popup Title - Video Gallery**

* Popup Title Font Size. Determine title size of the letters of popup
* Popup Title Font color. Configure preferable colour for title in popup

**Popup Link button - Video Gallery**

* Show Link button. Choose to make Link-button visible in popup 
* Link button Text. Edit the text of Link-button in popup 
* Link button Font Size. Set preferable size of the letters of Link-button in popup 
* Link button Font color. Configure the preferable colour for Link-button in popup
* Link button Font Hover color. Determine preferable colour of Link-button when you hover the mouse on it 
* Link button Background color. Specify preferable background colour of the Link-button in popup 
* Link button Background Hover color. Specify preferable background colour of the link as you hover the mouse on it.

### 2.2 Content video slider - Video Gallery

**Slider Container - Video Gallery**

* Main image Width. This fixes the margin of the main image
* Slider Background color. You can choose preferable colour for slider field
* Arrow Icons Style. Specify black/white colour of arrows in slider 
* Show Separator Lines. Choose to make the lines between text, title, and link visible

**Title - Video Gallery**

* Title Font Size. Configure the preferable size of the letters of the title 
* Title Font color. Configure the preferable colour of the font 

**Link button - Video Gallery**

* Show Link button. Click to show the Link-button 
* Link button Text. Write a text on link button
* Link button Font Size. Edit the size of the letters of the link text 
* Link button Font color. Edit the colour of the link text
* Link button Font Hover color. Edit the colour of the link text while hovering the mouse on it
* Link button Background color. Determine preferable colour for link field
* Link button Background Hover color. Choose a colour for your link background while hovering on it

**Description - Video Gallery**

* Show Description. Click to show the description of the text 
* Description Font Size. Specify preferable size of the letters of description 
* Description Font color. Choose a colour for description text in your “content video slider” view

### 2.3 LIghtbox-Video Gallery

**Video image - Video Gallery**

* Video-image Width. Specify preferable size of the video 
* Video-image Border Width. Specify preferable width of surrounded borders
* Video-image Border color. Configure your preferable the colour for border 
* Border Radius. Determine prefered radius of border corners

**Title - Video Gallery**

* Title Font Size. Specify the size for font of the title
* Title Font color. Configure the preferable colour for title
* Title Font Hover color. Configure the preferable of the title while hovering on it 
* Title Background color. Change title background colour, which comes up in closed position
* Title Background Transparency. Set level for title background transparency

### 2.4 Video Slider

**Video Slider - Video Gallery**

Video Behaviour. Choose “resized” to stretch and fit your videos to the size of Slider. 
Slider Background color. Set preferable color of the vacant part of slider field while images has its natural size 
Slideshow Border Size. Specify the size of the border in your slider
Slideshow Border color. Choose your prefered colour for border
Slideshow Border radius Determine preferable radius for slider border 

**Description - Video Gallery**

* Description Width. Select the width of description text box
* Description Has Margin. Determine if description need to have margin 
* Description Font Size. Specify the size of the letters in description
* Description Text color. Determine preferable color of the description text 
* Description Text Align. Specify the location of the description in the box	
* Description Background Transparency. Determine background transparency degree for description.
* Description Background colour. Determine the colour for description field
* Description Border Size. Specify preferable size for the description border. 
* Description Border color. Specify preferable colour of description border 
* Description Border Radius . Specify preferable corner’s radius of the description box 
* Description Position. Specify where to posite the description on the slider view

**Title - Video Gallery**

* Title Width. Determine the width for title box
* Title Has Margin. Click if you'd like the title to have margin 
* Title Font Size. Edit to set preferable size of the letters for the title 
* Title Text color. Edit to set preferable colour for the title
* Title Text Align. Specify the place of the title in the box	
* Title Background Transparency. 
* Title Background color. Determine preferable colour of title background
* Title Border Size. Specify preferable size of the title border 
* Title Border color. Determine preferable colour for the title border
* Title Border Radius. Specify preferable radius for border corners 
* Title Position. Specify preferable position of the title

**Navigation - Video Gallery**

* Show Navigation Arrows. Click to show navigation arrows in slider
* Navigation Dots Position / Hide Dots. Choose where to locate the dots, or choose to remove them
* Navigation Dots color. Choose the colour for navigation dots of slider
* Navigation Active Dot colour. Determine preferable colour of moving dots in slider
* Navigation Type.  Determine preferable type of your navigation arrows.

### 2.5 Thumbnails

**Image - Video Gallery**

* Video-image Behavior. Click to Determine behavior of video image
* Video-image Width. Allows to specify preferable width of thumbs 
* Video-image Height. Allows to specify preferable height of thumbs 
* Video-image Border Width. Allows to specify preferable width of the border between thumbs
* Video-image Border color.  Determine preferable colour of the border between thumbs 
* Border Radius. Allows to specify preferable radius of the border 
* Margin Video. Allows to specify the distance between each thumb


**Container Style - Video Gallery**

* Presence of a background. Click to have background for thumbs
* Box background color. Specify desired colour of surrounded box
* Box shadow. Click if you'd like to have shadows in the box
* Box padding. Specify desired distance between box and video 

**Title - Video Gallery**

* Title Font Size. Specify preferable size of the text font 
* Title Font color. determine preferable colour of text 
* Overlay Background color. Determine the overlay colour of the title 
* Title Background Transparency. Specify the degree of background transparency 
* Link text. Wright desired text for the link.

